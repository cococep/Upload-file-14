package com.tutorial;

public class Main {

    public static void main(String[] args){
        System.out.println("hallo " + args[0] + " ganteng");
        System.out.println("hallo " + args[1] + " Manise");
    }
}
