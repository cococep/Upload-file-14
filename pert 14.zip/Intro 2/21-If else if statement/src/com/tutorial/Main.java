package com.tutorial;

public class Main {

    public static void main (String[] args){

        // tutorialif else if statement

        int a = 5;

        System.out.println("ini adalah awal program");

        // if else if statement

        if (a == 5){

            System.out.println("ini adalah aksi 1");

        } else if (a == 10) {

            System.out.println("ini adalah aksi 2");

        } else {

            System.out.println("ini adalah aksi default");

        }

        // akhir dari if else if statement

        System.out.println("ini adalah akhir program");


    }
}
