# TUGAS - PERTEMUAN 13

1. Kerjakan ulang dari latihan `04` sampai `51` di pertemuan `13` ini.
2. Pahami setiap maksud dari code nya.
3. Jalankan sampai buildnya success di tiap latihannya.
4. Buat masing-masing latihan tersebut ke dalam masing-masing project yang berbeda dengan ketentuan nama project :       Contoh : `08-Variable`
5. Didalam codingan, berikan `comment identitas diri` diatas nama `class`
6. PUSH setiap project ke akun guthub masing-masing. dengan subject `JAVA-PERT-13`

---- 

![Steve Jobs](https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ0DHtd3ACLG0o8ZrMP_4M3s0vxyGOLrYiZZnaTp0fiVia7w3yV)

*image source : [made4dev.com](https://made4dev.com/) #programmingQuotes*